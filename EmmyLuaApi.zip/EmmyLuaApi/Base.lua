﻿---@class Base : MonoBehaviour
local Base={ }
.Base = Base