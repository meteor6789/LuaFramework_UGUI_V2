﻿---@class LightType : Enum
---@field public value__ Int32
---@field public Spot number
---@field public Directional number
---@field public Point number
---@field public Area number
---@field public Rectangle number
---@field public Disc number
local LightType={ }
UnityEngine.LightType = LightType