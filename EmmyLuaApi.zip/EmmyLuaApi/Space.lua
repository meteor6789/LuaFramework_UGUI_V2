﻿---@class Space : Enum
---@field public value__ Int32
---@field public World number
---@field public Self number
local Space={ }
UnityEngine.Space = Space