﻿---@class AudioBehaviour : Behaviour
local AudioBehaviour={ }
UnityEngine.AudioBehaviour = AudioBehaviour