﻿---@class View : Base
local View={ }
---@public
---@param message IMessage
---@return void
function View:OnMessage(message) end
.View = View