﻿---@class GameManager : Manager
local GameManager={ }
---@public
---@return void
function GameManager:CheckExtractResource() end
---@public
---@return void
function GameManager:OnResourceInited() end
LuaFramework.GameManager = GameManager