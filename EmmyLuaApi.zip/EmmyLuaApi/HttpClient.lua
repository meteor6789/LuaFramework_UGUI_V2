﻿---@class HttpClient : MonoBehaviour
---@field public baseUrl string
---@field public headers Dictionary`2
---@field public Instance HttpClient
local HttpClient={ }
---@public
---@param url string
---@param action LuaFunction
---@return void
function HttpClient:Get(url, action) end
---@public
---@param url string
---@param action LuaFunction
---@return void
function HttpClient:Delete(url, action) end
---@public
---@param url string
---@param data string
---@param action LuaFunction
---@return void
function HttpClient:Put(url, data, action) end
---@public
---@param url string
---@param postData string
---@param action LuaFunction
---@return void
function HttpClient:Post(url, postData, action) end
---@public
---@param url string
---@param action LuaFunction
---@return void
function HttpClient:GetTexture(url, action) end
---@public
---@param url string
---@param actionResult LuaFunction
---@return void
function HttpClient:GetAssetBundle(url, actionResult) end
---@public
---@param url string
---@param actionResult LuaFunction
---@param audioType number
---@return void
function HttpClient:GetAudioClip(url, actionResult, audioType) end
---@public
---@param url string
---@param filePath string
---@param actionResult LuaFunction
---@param contentType string
---@return void
function HttpClient:UploadByPut(url, filePath, actionResult, contentType) end
---@public
---@param heads string
---@return void
function HttpClient:SetHeads(heads) end
LuaFramework.HttpClient = HttpClient