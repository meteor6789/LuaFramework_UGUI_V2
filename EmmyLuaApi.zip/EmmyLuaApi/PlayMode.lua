﻿---@class PlayMode : Enum
---@field public value__ Int32
---@field public StopSameLayer number
---@field public StopAll number
local PlayMode={ }
UnityEngine.PlayMode = PlayMode