﻿---@class SleepTimeout : Object
---@field public NeverSleep Int32
---@field public SystemSetting Int32
local SleepTimeout={ }
UnityEngine.SleepTimeout = SleepTimeout