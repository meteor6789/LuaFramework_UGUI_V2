﻿---@class AppConst : Object
---@field public DebugMode bool
---@field public ExampleMode bool
---@field public UpdateMode bool
---@field public LuaByteMode bool
---@field public LuaBundleMode bool
---@field public TimerInterval Int32
---@field public GameFrameRate Int32
---@field public AppName string
---@field public LuaTempDir string
---@field public AppPrefix string
---@field public ExtName string
---@field public AssetDir string
---@field public WebUrl string
---@field public UserId string
---@field public SocketPort Int32
---@field public SocketAddress string
---@field public FrameworkRoot string
local AppConst={ }
LuaFramework.AppConst = AppConst