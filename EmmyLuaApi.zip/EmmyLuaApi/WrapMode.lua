﻿---@class WrapMode : Enum
---@field public value__ Int32
---@field public Once number
---@field public Loop number
---@field public PingPong number
---@field public Default number
---@field public ClampForever number
---@field public Clamp number
local WrapMode={ }
UnityEngine.WrapMode = WrapMode