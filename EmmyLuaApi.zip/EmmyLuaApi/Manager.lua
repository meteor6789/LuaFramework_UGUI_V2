﻿---@class Manager : Base
local Manager={ }
.Manager = Manager