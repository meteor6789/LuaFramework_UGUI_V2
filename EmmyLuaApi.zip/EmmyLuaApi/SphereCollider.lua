﻿---@class SphereCollider : Collider
---@field public center Vector3
---@field public radius Single
local SphereCollider={ }
UnityEngine.SphereCollider = SphereCollider