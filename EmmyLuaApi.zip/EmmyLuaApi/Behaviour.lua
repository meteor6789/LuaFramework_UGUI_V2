﻿---@class Behaviour : Component
---@field public enabled bool
---@field public isActiveAndEnabled bool
local Behaviour={ }
UnityEngine.Behaviour = Behaviour