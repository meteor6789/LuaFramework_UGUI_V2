﻿---@class CameraClearFlags : Enum
---@field public value__ Int32
---@field public Skybox number
---@field public Color number
---@field public SolidColor number
---@field public Depth number
---@field public Nothing number
local CameraClearFlags={ }
UnityEngine.CameraClearFlags = CameraClearFlags