﻿---@class PlatformInvoke : Object
local PlatformInvoke={ }
---@public
---@param clsName string
---@param javaFuncName string
---@param args Object[]
---@return void
function PlatformInvoke.CallJavaFunc(clsName, javaFuncName, args) end
LuaFramework.PlatformInvoke = PlatformInvoke