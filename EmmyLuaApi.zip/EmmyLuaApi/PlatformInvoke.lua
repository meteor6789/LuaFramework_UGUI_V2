﻿---@class PlatformInvoke : MonoBehaviour
local PlatformInvoke={ }
---@public
---@param type Int32
---@param content string
---@return Int32
function PlatformInvoke:LuaCallAndroid(type, content) end
---@public
---@param content string
---@return Int32
function PlatformInvoke:AndroidCallLua(content) end
LuaFramework.PlatformInvoke = PlatformInvoke