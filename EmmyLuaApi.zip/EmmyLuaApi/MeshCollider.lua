﻿---@class MeshCollider : Collider
---@field public sharedMesh Mesh
---@field public convex bool
---@field public cookingOptions number
---@field public smoothSphereCollisions bool
---@field public skinWidth Single
---@field public inflateMesh bool
local MeshCollider={ }
UnityEngine.MeshCollider = MeshCollider