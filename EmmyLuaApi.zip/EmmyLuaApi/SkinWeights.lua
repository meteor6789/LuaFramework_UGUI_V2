﻿---@class SkinWeights : Enum
---@field public value__ Int32
---@field public OneBone number
---@field public TwoBones number
---@field public FourBones number
---@field public Unlimited number
local SkinWeights={ }
UnityEngine.SkinWeights = SkinWeights