﻿---@class QueueMode : Enum
---@field public value__ Int32
---@field public CompleteOthers number
---@field public PlayNow number
local QueueMode={ }
UnityEngine.QueueMode = QueueMode