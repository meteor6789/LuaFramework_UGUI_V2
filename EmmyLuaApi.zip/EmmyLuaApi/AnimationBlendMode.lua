﻿---@class AnimationBlendMode : Enum
---@field public value__ Int32
---@field public Blend number
---@field public Additive number
local AnimationBlendMode={ }
UnityEngine.AnimationBlendMode = AnimationBlendMode