﻿---@class UIBehaviour : MonoBehaviour
local UIBehaviour={ }
---@public
---@return bool
function UIBehaviour:IsActive() end
---@public
---@return bool
function UIBehaviour:IsDestroyed() end
UnityEngine.EventSystems.UIBehaviour = UIBehaviour