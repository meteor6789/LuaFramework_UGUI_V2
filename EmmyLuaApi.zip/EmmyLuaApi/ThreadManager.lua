﻿---@class ThreadManager : Manager
local ThreadManager={ }
---@public
---@param ev ThreadEvent
---@param func Action`1
---@return void
function ThreadManager:AddEvent(ev, func) end
LuaFramework.ThreadManager = ThreadManager