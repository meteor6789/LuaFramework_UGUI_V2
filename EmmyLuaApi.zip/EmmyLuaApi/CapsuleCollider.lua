﻿---@class CapsuleCollider : Collider
---@field public center Vector3
---@field public radius Single
---@field public height Single
---@field public direction Int32
local CapsuleCollider={ }
UnityEngine.CapsuleCollider = CapsuleCollider