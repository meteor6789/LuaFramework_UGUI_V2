﻿---@class BoxCollider : Collider
---@field public center Vector3
---@field public size Vector3
---@field public extents Vector3
local BoxCollider={ }
UnityEngine.BoxCollider = BoxCollider