﻿---@class InjectType : Enum
---@field public value__ Int32
---@field public None number
---@field public After number
---@field public Before number
---@field public Replace number
---@field public ReplaceWithPreInvokeBase number
---@field public ReplaceWithPostInvokeBase number
local InjectType={ }
LuaInterface.InjectType = InjectType